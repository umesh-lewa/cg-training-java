package factorypack;

public interface Exporter {
	public void doExport();
}

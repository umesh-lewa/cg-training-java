package annoshoepack;

public abstract class Shoe {

}

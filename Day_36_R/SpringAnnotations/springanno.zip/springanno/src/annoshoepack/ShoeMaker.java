package annoshoepack;

public interface ShoeMaker {
	public Shoe makeShoe();
}

package annoshoepack;

public class SportsShoe extends Shoe{

}

package annoshoepack;

public abstract class ShoeFactory implements ShoeMaker {

}

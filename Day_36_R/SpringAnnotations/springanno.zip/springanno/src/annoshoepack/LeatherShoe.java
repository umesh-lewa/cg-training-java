package annoshoepack;

public class LeatherShoe extends Shoe{

}

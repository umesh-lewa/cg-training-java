package annoshoepack;

public interface Seller {
	public Shoe sellShoe(Customer customer);
	public void test();
}

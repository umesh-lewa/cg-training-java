package annoshoepack;

public interface Exporter {
	public void doExport();
}

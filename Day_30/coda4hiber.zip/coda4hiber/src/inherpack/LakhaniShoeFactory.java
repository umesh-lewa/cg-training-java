package inherpack;

public class LakhaniShoeFactory extends ShoeFactory{
	private String lakhaniName;

	public String getLakhaniName() {
		return lakhaniName;
	}

	public void setLakhaniName(String lakhaniName) {
		this.lakhaniName = lakhaniName;
	}
}
